import json
import jwt
import time
import boto3
from botocore.exceptions import ClientError

SECRET_KEY = "D9texL9_fknC5cb0h-ik2INJyzdona14ZlHoLuOA8nE="
DYNAMODB_TABLE = "Client"
JWT_ALGORITHM = 'HS256'


def lambda_handler(event, context):
    body = json.loads(event.get('body', '{}'))
    username = body.get('username')
    password = body.get('password')

    if not username or not password:
        return {
            'statusCode': 400,
            'body': json.dumps({'error': 'Username and password are required'})
        }

    # Authenticate user
    if not authenticate_user(username, password):
        return {
            'statusCode': 401,
            'body': json.dumps({'error': 'Invalid username or password'})
        }

    # Generate JWT token
    token = generate_jwt_token(username)

    return {
        'statusCode': 200,
        'body': json.dumps({'token': token})
    }


def authenticate_user(username, password):
    # Check username and password against the DynamoDB table
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table(DYNAMODB_TABLE)

    try:
        response = table.get_item(Key={'username': username})
    except ClientError as e:
        print(e.response['Error']['Message'])
        return False
    else:
        user = response.get('Item')
        if user and user['password'] == password:
            return True
    return False


def generate_jwt_token(username):
    payload = {
        'username': username,
        'exp': int(time.time()) + 3600  # Token expires in 1 hour
    }
    token = jwt.encode(payload, SECRET_KEY, algorithm=JWT_ALGORITHM)
    return token
